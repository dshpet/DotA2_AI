Pub Simulator 1.0

Hello Everyone,

These bots are written by PLATINUM (Pooya J. also known as PLATINUM_DOTA2). You are
 free to use all of the codes for any non-commercial purposes you choose, with a reference to the
 original Author. Do not use any of the files here for any program which is not open source and free
to use. All the comments made by the bots during the game are for entertainment purposes.

How to use the bots:
Copy all the files in the following address (it can vary if you have installed
your steam or DOTA 2 in another folder):
"C:\Program Files (x86)\Steam\steamapps\common\dota 2 beta\game\dota\scripts\vscripts\bots"

Note that the "bots" folder doesn't exist by default and you may have to create it. In order to play 
with the bots, open Dota 2, open "CREAT LOBBY", open "EDIT", in the "ADVANCED LOBBY SETTINGS", 
check "FILL EMPTY SLOTS WITH BOTS" and select "LOCAL DEV SCRIPT" on either radiant or dire. 
I have written bots for 5 heroes (a team), so it is better to select them for one side. However, 
you can use them for both radiant or dire, which may be suitable for players who want to play 
together in a XvX format (1<=X<=4) in a local host and are missing a few players.

These bots do not change their lanes automatically, so if you want to play with them and change their 
lanes, you should change the "hero_selection.lua" file (it is not hard to do this, you don't need to 
know programming to do so).

PS. Valve's API is feeding the courier and I cannot do anything about it :D Hopefully they will fix 
their API soon.

I hope you enjoy this!
Cheers,
Pooya J (PLATINUM)
Email: platinum.dota2@gmail.com
